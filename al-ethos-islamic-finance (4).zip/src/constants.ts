import { Product, ProductType } from './types';

export const PRODUCTS: Product[] = [
  {
    id: 'ijarah-car-01',
    type: ProductType.IJARAH,
    name: 'Al-Safeer Car Ijarah',
    description: 'A lease-to-own agreement where the bank purchases the vehicle and leases it to you for a fixed period.',
    shariahBase: 'Ijarah Muntahia Bittamleek',
    minAmount: 15000,
    tenureMonths: 60,
  },
  {
    id: 'musharakah-home-01',
    type: ProductType.MUSHARAKAH,
    name: 'Baitul-Aman Home Finance',
    description: 'Shared ownership of a property where you gradually buy out the bank’s share over time.',
    shariahBase: 'Diminishing Musharakah',
    minAmount: 100000,
    tenureMonths: 240,
  },
  {
    id: 'mudaraba-inv-01',
    type: ProductType.MUDARABA,
    name: 'Ethos Growth Fund',
    description: 'Profit-sharing investment where the bank manages your capital in Shariah-compliant businesses.',
    shariahBase: 'Mudaraba',
    minAmount: 5000,
    expectedProfitRate: 7.5,
    tenureMonths: 12,
  },
  {
    id: 'wakalah-inv-01',
    type: ProductType.WAKALAH,
    name: 'Safe-Yield Wakalah',
    description: 'The bank acts as your agent to invest in specific assets for a fixed agency fee (Wakala fee).',
    shariahBase: 'Wakalah Bi Al-Istithmar',
    minAmount: 10000,
    expectedProfitRate: 5.2,
    tenureMonths: 24,
  },
];

export const INITIAL_CUSTOMERS = [
  {
    id: 'c-001',
    name: 'Ahmad Abdullah',
    email: 'ahmad.a@example.com',
    onboardingStatus: 'Completed',
    riskProfile: 'Low',
  },
  {
    id: 'c-002',
    name: 'Fatima Zahra',
    email: 'fatima.z@example.com',
    onboardingStatus: 'InReview',
    riskProfile: 'Medium',
  }
];
