/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Sidebar } from './components/Sidebar';
import { DashboardView } from './components/DashboardView';
import { ProductCatalogue } from './components/ProductCatalogue';
import { LedgerView } from './components/LedgerView';
import { OnboardingView } from './components/OnboardingView';
import { ShariahAdvisorView } from './components/ShariahAdvisorView';
import { ComplianceMonitorView } from './components/ComplianceMonitorView';
import { ArchitectureView } from './components/ArchitectureView';
import { PresentationView } from './components/PresentationView';
import { TransactionModal } from './components/TransactionModal';
import { blockchainService } from './services/blockchain';
import { Product, Transaction, Block } from './types';
import { Bell, Search, User, Zap, Database } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export default function App() {
  const [activeTab, setActiveTab] = useState('dashboard');
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [chain, setChain] = useState<Block[]>([]);
  const [isInitializing, setIsInitializing] = useState(true);

  useEffect(() => {
    async function initBlockchain() {
      await blockchainService.createGenesisBlock();
      setChain(blockchainService.getChain());
      setIsInitializing(false);
    }
    initBlockchain();
  }, []);

  const handleCommit = async (tx: Transaction, advice: string, status: 'PASSED' | 'WARNING' | 'FAILED') => {
    await blockchainService.addBlock([tx], advice, status);
    setChain(blockchainService.getChain());
    setSelectedProduct(null);
    setActiveTab('ledger'); // Switch to ledger to see the transaction recorded
  };

  const handleSeedDemo = async () => {
    await blockchainService.seedDemoData();
    setChain(blockchainService.getChain());
  };

  if (isInitializing) {
    return (
      <div className="h-screen w-screen bg-slate-950 flex items-center justify-center">
        <div className="text-center space-y-4">
          <div className="w-12 h-12 bg-emerald-500 rounded-2xl mx-auto animate-bounce flex items-center justify-center">
            <div className="w-6 h-6 border-4 border-white border-t-transparent rounded-full animate-spin" />
          </div>
          <p className="text-emerald-500 font-mono text-xs tracking-widest uppercase">Initializing Shariah Ledger...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="flex h-screen bg-bento-bg font-sans text-slate-100 overflow-hidden">
      <Sidebar activeTab={activeTab} setActiveTab={setActiveTab} />
      
      <main className="flex-1 flex flex-col min-w-0">
        {/* Top Header - Bento Inspired */}
        <header className="h-20 border-b border-bento-border/30 px-8 flex items-center justify-between shrink-0 bg-bento-bg/50 backdrop-blur-md z-10">
          <div className="flex items-center gap-6">
            <div className="flex items-center gap-4 bg-slate-900/60 border border-bento-border/30 rounded-full px-5 py-2 w-80">
              <Search className="w-4 h-4 text-slate-500" />
              <input 
                type="text" 
                placeholder="Query Shariah records..." 
                className="bg-transparent border-none outline-none text-xs w-full text-slate-300 placeholder:text-slate-600"
              />
            </div>
            <div className="flex items-center gap-2 bg-emerald-500/10 px-3 py-1.5 rounded-full border border-emerald-500/20">
              <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
              <span className="text-[10px] font-bold text-emerald-400 uppercase tracking-widest">Gemini AI Core Active</span>
            </div>
          </div>

          <div className="flex items-center gap-6">
            <button className="p-2.5 bg-slate-900/40 rounded-xl border border-bento-border/20 text-slate-400 hover:text-white transition-all relative group">
              <Bell className="w-5 h-5 group-hover:scale-110 transition-transform" />
              <span className="absolute top-0 right-0 w-2 h-2 bg-rose-500 rounded-full border-2 border-bento-bg" />
            </button>
            <div className="flex items-center gap-4 pl-4 border-l border-bento-border/30">
              <div className="text-right">
                <p className="text-xs font-bold text-white whitespace-nowrap">Bank Admin Node</p>
                <p className="text-[10px] text-slate-500 font-medium">Dubai Central 01</p>
              </div>
              <div className="w-10 h-10 rounded-2xl bg-slate-800 border border-bento-border/50 flex items-center justify-center group cursor-pointer hover:border-emerald-500/50 transition-all">
                <User className="w-5 h-5 text-slate-400 group-hover:text-emerald-400" />
              </div>
            </div>
          </div>
        </header>

        {/* Scrollable Content Area */}
        <div className="flex-1 overflow-y-auto p-8 relative">
          <AnimatePresence mode="wait">
            <motion.div
              key={activeTab}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.2 }}
            >
              {activeTab === 'dashboard' && <DashboardView />}
              {activeTab === 'onboarding' && <OnboardingView />}
              {activeTab === 'products' && <ProductCatalogue onSelect={setSelectedProduct} />}
              {activeTab === 'ledger' && <LedgerView chain={chain} />}
              {activeTab === 'advisor' && <ShariahAdvisorView />}
              {activeTab === 'compliance' && <ComplianceMonitorView />}
              {activeTab === 'architecture' && <ArchitectureView />}
              {activeTab === 'presentation' && <PresentationView />}
              {activeTab === 'transactions' && (
                <div className="flex flex-col items-center justify-center p-20 text-center space-y-4">
                   <div className="p-6 bg-slate-900 rounded-3xl ring-8 ring-emerald-500/10">
                     <Database className="w-12 h-12 text-emerald-500" />
                   </div>
                   <h2 className="text-2xl font-bold text-white">Advanced Ledger Query</h2>
                   <p className="text-slate-500 max-w-sm">Detailed transaction history is being indexed for high-performance querying.</p>
                </div>
              )}
            </motion.div>
          </AnimatePresence>

          {/* Floating Hackathon Demo Button */}
          <button 
            onClick={handleSeedDemo}
            className="fixed bottom-8 right-8 bg-emerald-600 hover:bg-emerald-500 text-white flex items-center gap-2 px-6 py-3 rounded-full font-bold shadow-[0_0_30px_rgba(16,185,129,0.4)] transition-all active:scale-95 group z-50 border border-emerald-400/30"
          >
            <Zap className="w-5 h-5 group-hover:animate-pulse" />
            Seed Demo Data
          </button>
        </div>
      </main>

      <TransactionModal 
        product={selectedProduct} 
        onClose={() => setSelectedProduct(null)} 
        onCommit={handleCommit}
      />
    </div>
  );
}

