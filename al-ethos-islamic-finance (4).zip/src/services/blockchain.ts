import { Block, Transaction, ContractStatus } from '../types';

async function calculateHash(index: number, timestamp: number, transactions: Transaction[], previousHash: string, nonce: number): Promise<string> {
  const data = JSON.stringify({ index, timestamp, transactions, previousHash, nonce });
  const msgBuffer = new TextEncoder().encode(data);
  const hashBuffer = await crypto.subtle.digest('SHA-256', msgBuffer);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
}

export class Blockchain {
  chain: Block[] = [];
  
  constructor() {
    // We start empty, the App will initialize the genesis block
  }

  async createGenesisBlock(): Promise<Block> {
    const timestamp = Date.now();
    const hash = await calculateHash(0, timestamp, [], '0', 0);
    const genesisBlock: Block = {
      index: 0,
      timestamp,
      transactions: [],
      previousHash: '0',
      hash,
      nonce: 0,
      monitoringStatus: 'PASSED',
      shariahAdvice: 'Genesis block established. System initialized.'
    };
    this.chain = [genesisBlock];
    return genesisBlock;
  }

  getLatestBlock(): Block {
    return this.chain[this.chain.length - 1];
  }

  async addBlock(transactions: Transaction[], shariahAdvice: string, status: 'PASSED' | 'WARNING' | 'FAILED'): Promise<Block> {
    const previousBlock = this.getLatestBlock();
    const index = previousBlock.index + 1;
    const timestamp = Date.now();
    const previousHash = previousBlock.hash;
    let nonce = 0;
    let hash = await calculateHash(index, timestamp, transactions, previousHash, nonce);

    // Simple proof of work (if we wanted to simulate it, but for a demo we just need the hash)
    // while (!hash.startsWith('00')) {
    //   nonce++;
    //   hash = await calculateHash(index, timestamp, transactions, previousHash, nonce);
    // }

    const newBlock: Block = {
      index,
      timestamp,
      transactions,
      previousHash,
      hash,
      nonce,
      shariahAdvice,
      monitoringStatus: status
    };

    this.chain.push(newBlock);
    return newBlock;
  }

  getChain(): Block[] {
    return [...this.chain];
  }

  async seedDemoData(): Promise<void> {
    const demoData = [
      {
        advice: "Traditional Ijarah contract structure identified. Ownership risk strictly maintained by lessor. PASSED.",
        status: 'PASSED' as const,
        amount: 25000,
        type: 'INITIAL' as const
      },
      {
        advice: "WARNING: Late payment penalty structure detected. Diverting penalty funds to Shariah-approved charity nodes to avoid Riba classification.",
        status: 'WARNING' as const,
        amount: 450,
        type: 'LEAS_PAYMENT' as const
      },
      {
        advice: "Musharakah equity buy-back verified. Fractional ownership updated on distributed ledger. PASSED.",
        status: 'PASSED' as const,
        amount: 1500,
        type: 'PARTIAL_OWNERSHIP' as const
      }
    ];

    for (const data of demoData) {
      const tx: Transaction = {
        id: `tx-demo-${Math.random().toString(36).substr(2, 5)}`,
        customerId: 'c-001',
        productId: 'musharakah-home-01',
        amount: data.amount,
        timestamp: Date.now() - (Math.random() * 10000000),
        status: data.status === 'PASSED' ? ContractStatus.ACTIVE : ContractStatus.FLAGGED,
        type: data.type,
      };
      await this.addBlock([tx], data.advice, data.status);
    }
  }
}

export const blockchainService = new Blockchain();
