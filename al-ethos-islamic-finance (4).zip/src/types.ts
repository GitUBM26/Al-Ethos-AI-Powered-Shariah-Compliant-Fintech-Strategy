/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export enum ProductType {
  MUDARABA = 'Mudaraba',
  WAKALAH = 'Wakalah',
  IJARAH = 'Car Ijarah',
  MUSHARAKAH = 'Diminishing Musharakah',
}

export interface Product {
  id: string;
  type: ProductType;
  name: string;
  description: string;
  shariahBase: string;
  minAmount: number;
  expectedProfitRate?: number;
  tenureMonths: number;
}

export enum ContractStatus {
  PENDING = 'Pending',
  VERIFIED = 'Verified',
  SIGNED = 'Signed',
  ACTIVE = 'Active',
  CLOSED = 'Closed',
  FLAGGED = 'Flagged',
}

export interface Customer {
  id: string;
  name: string;
  email: string;
  onboardingStatus: 'Completed' | 'Pending' | 'InReview';
  riskProfile: 'Low' | 'Medium' | 'High';
}

export interface Transaction {
  id: string;
  customerId: string;
  productId: string;
  amount: number;
  timestamp: number;
  status: ContractStatus;
  type: 'INITIAL' | 'MONTHLY_PAYMENT' | 'PARTIAL_OWNERSHIP' | 'LEAS_PAYMENT';
}

export interface Block {
  index: number;
  timestamp: number;
  transactions: Transaction[];
  previousHash: string;
  hash: string;
  nonce: number;
  shariahAdvice?: string;
  monitoringStatus: 'PASSED' | 'WARNING' | 'FAILED';
}

export interface VeeaAudit {
  id: string;
  transactionId: string;
  timestamp: number;
  advice: string;
  complianceScore: number; // 0-100
  flagged: boolean;
}
