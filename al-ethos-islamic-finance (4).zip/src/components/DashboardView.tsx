import React from 'react';
import { 
  TrendingUp, 
  Users, 
  Activity, 
  ShieldAlert,
  ArrowUpRight,
  ArrowDownRight,
  Download,
  Presentation
} from 'lucide-react';
import { 
  AreaChart, 
  Area, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  BarChart,
  Bar
} from 'recharts';
import { formatCurrency, cn } from '../lib/utils';

const data = [
  { name: 'Jan', volume: 4000, compliance: 98 },
  { name: 'Feb', volume: 3000, compliance: 95 },
  { name: 'Mar', volume: 2000, compliance: 99 },
  { name: 'Apr', volume: 2780, compliance: 92 },
  { name: 'May', volume: 1890, compliance: 97 },
  { name: 'Jun', volume: 2390, compliance: 96 },
  { name: 'Jul', volume: 3490, compliance: 99 },
];

export function DashboardView() {
  return (
    <div className="space-y-8 max-w-7xl mx-auto">
      <header className="flex justify-between items-end mb-4">
        <div>
          <h2 className="text-3xl font-sans font-bold text-white tracking-tight">Institutional Portal</h2>
          <p className="text-slate-500 text-sm mt-1">Real-time Shariah compliance and transaction performance nodes.</p>
        </div>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-12 gap-5 auto-rows-[160px]">
        {/* Main Volume Chart Card */}
        <div className="md:col-span-8 md:row-span-3 bento-card bg-gradient-to-br from-slate-900/80 to-emerald-950/20">
          <div className="flex justify-between items-center mb-6">
            <div>
              <span className="label-xs">Transaction Volume (Institutional)</span>
              <h3 className="text-lg font-bold text-white">Daily Operations</h3>
            </div>
            <div className="flex gap-2">
              <span className="px-2 py-0.5 bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 rounded text-[9px] font-bold">LIVE SYNC</span>
            </div>
          </div>
          <div className="h-[320px]">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={data}>
                <defs>
                  <linearGradient id="colorVolume" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#10b981" stopOpacity={0.2}/>
                    <stop offset="95%" stopColor="#10b981" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#1e293b" />
                <XAxis dataKey="name" stroke="#475569" fontSize={10} axisLine={false} tickLine={false} />
                <YAxis stroke="#475569" fontSize={10} axisLine={false} tickLine={false} tickFormatter={(val) => `$${val/1000}k`} />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#0f172a', border: '1px solid #1e293b', borderRadius: '12px', color: '#fff' }}
                  itemStyle={{ color: '#10b981' }}
                />
                <Area type="monotone" dataKey="volume" stroke="#10b981" fillOpacity={1} fill="url(#colorVolume)" strokeWidth={2} />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* AI Insight Card */}
        <div className="md:col-span-4 md:row-span-2 bento-card relative overflow-hidden group">
          <div className="absolute top-0 right-0 p-4 opacity-5 group-hover:opacity-10 transition-opacity">
            <ShieldAlert className="w-24 h-24" />
          </div>
          <span className="label-xs">Veea Shariah Insight Engine</span>
          <p className="text-sm text-slate-300 leading-relaxed italic mb-6 relative z-10">
            "Current market volatility suggests a temporary 0.5% adjustment in Musharakah profit-sharing ratios to maintain equity. Veea monitoring confirms zero non-compliant leakage in last 24h."
          </p>
          <div className="flex flex-wrap gap-2 mt-auto">
            <span className="px-2 py-0.5 bg-emerald-500/5 border border-emerald-500/20 text-emerald-400 rounded-full text-[10px] font-bold">99.9% Shariah Index</span>
            <span className="px-2 py-0.5 bg-emerald-500/5 border border-emerald-500/20 text-emerald-400 rounded-full text-[10px] font-bold">AA+ Fatwa Rating</span>
          </div>
        </div>

        {/* Stat Cards */}
        <div className="md:col-span-4 md:row-span-1 bento-card flex flex-col justify-center">
          <span className="label-xs text-emerald-500">Total AuM</span>
          <div className="flex items-end justify-between">
            <span className="text-2xl font-bold font-mono tracking-tight">$12.45M</span>
            <span className="text-emerald-400 text-xs font-bold mb-1 flex items-center"><ArrowUpRight className="w-3 h-3" /> 12.5%</span>
          </div>
        </div>

        <div className="md:col-span-4 md:row-span-1 bento-card flex flex-col justify-center">
          <span className="label-xs">Active Institutional Customers</span>
          <div className="flex items-end justify-between">
            <span className="text-2xl font-bold font-mono tracking-tight">2,481</span>
            <span className="text-emerald-400 text-xs font-bold mb-1 flex items-center"><ArrowUpRight className="w-3 h-3" /> +43</span>
          </div>
        </div>

        <div className="md:col-span-4 md:row-span-2 bento-card">
          <span className="label-xs">Compliance Score per Facility</span>
          <div className="h-[220px] mt-4">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={data}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#1e293b" />
                <XAxis dataKey="name" stroke="#475569" fontSize={10} axisLine={false} tickLine={false} />
                <Tooltip 
                   contentStyle={{ backgroundColor: '#0f172a', border: '1px solid #1e293b', borderRadius: '12px', color: '#fff' }}
                />
                <Bar dataKey="compliance" fill="#10b981" radius={[4, 4, 0, 0]} opacity={0.8} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="md:col-span-4 md:row-span-1 bento-card flex flex-col justify-center bg-emerald-950/30 border-emerald-500/20">
           <div className="flex items-center gap-2 mb-2">
             <ShieldAlert className="w-4 h-4 text-emerald-400" />
             <span className="label-xs text-emerald-400 mb-0">Sentinel Status</span>
           </div>
           <p className="text-xs text-slate-300">Veea Execution Layer is fully encrypted and monitoring all contract signatures.</p>
        </div>

        {/* New Marketing Assets Card */}
        <div className="md:col-span-8 md:row-span-1 bento-card flex items-center justify-between bg-slate-900/40 border-bento-border/20 group">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 bg-white/5 rounded-2xl flex items-center justify-center border border-white/10 group-hover:border-emerald-500/30 transition-colors">
              <Presentation className="w-6 h-6 text-emerald-500" />
            </div>
            <div>
              <h4 className="text-sm font-bold text-white uppercase tracking-tight">Marketing Assets</h4>
              <p className="text-[10px] text-slate-500 font-medium">Download latest Pitch Deck and Cover Images for the Al-Ethos demo.</p>
            </div>
          </div>
          <div className="flex gap-3">
            <button 
              className="px-4 py-2 bg-emerald-600/10 hover:bg-emerald-600/20 text-emerald-400 rounded-xl text-[10px] font-bold uppercase tracking-widest transition-all border border-emerald-500/20 flex items-center gap-2"
              onClick={(e) => { e.preventDefault(); alert("Please navigate to the 'Pitch Deck' tab to generate and download high-resolution marketing assets."); }}
            >
              <Download className="w-3.5 h-3.5" />
              Cover Image
            </button>
            <button 
              className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-white rounded-xl text-[10px] font-bold uppercase tracking-widest transition-all border border-white/5 flex items-center gap-2"
              onClick={(e) => { e.preventDefault(); alert("Please navigate to the 'Pitch Deck' tab to generate and download the full Pitch Deck PDF."); }}
            >
              <Download className="w-3.5 h-3.5" />
              Pitch Deck
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
