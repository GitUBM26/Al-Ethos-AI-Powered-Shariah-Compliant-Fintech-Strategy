import React, { useState } from 'react';
import { 
  X, 
  UserPlus, 
  ShieldCheck, 
  Fingerprint, 
  Target,
  Loader2,
  CheckCircle2
} from 'lucide-react';
import { cn } from '../lib/utils';
import { motion, AnimatePresence } from 'motion/react';

interface OnboardingModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: (customer: any) => void;
}

export function OnboardingModal({ isOpen, onClose, onSuccess }: OnboardingModalProps) {
  const [step, setStep] = useState<'FORM' | 'VERIFYING' | 'SUCCESS'>('FORM');
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [risk, setRisk] = useState<'Low' | 'Medium' | 'High'>('Low');

  if (!isOpen) return null;

  const handleOnboard = () => {
    setStep('VERIFYING');
    setTimeout(() => {
      const newCustomer = {
        id: `c-${Math.floor(Math.random() * 1000)}`,
        name,
        email,
        onboardingStatus: 'Completed',
        riskProfile: risk,
      };
      setStep('SUCCESS');
      setTimeout(() => {
        onSuccess(newCustomer);
        setStep('FORM');
        setName('');
        setEmail('');
        onClose();
      }, 2000);
    }, 3000);
  };

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md">
        <motion.div 
          initial={{ opacity: 0, scale: 0.9, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.9, y: 20 }}
          className="bg-slate-900 w-full max-w-md rounded-[2.5rem] overflow-hidden border border-bento-border/30 shadow-2xl relative"
        >
          <button onClick={onClose} className="absolute top-6 right-6 p-2 text-slate-500 hover:text-white transition-colors bg-slate-950/50 rounded-xl">
            <X className="w-5 h-5" />
          </button>

          {step === 'FORM' && (
            <div className="p-10">
              <div className="flex items-center gap-4 mb-8">
                <div className="p-3 bg-emerald-500/10 text-emerald-500 rounded-2xl border border-emerald-500/20">
                  <UserPlus className="w-7 h-7" />
                </div>
                <div>
                  <h3 className="font-bold text-white text-lg">New Institutional Entry</h3>
                  <p className="text-[10px] text-emerald-500 font-mono tracking-widest uppercase font-bold">Protocol KYC-v4</p>
                </div>
              </div>

              <div className="space-y-5">
                <div className="space-y-2">
                  <label className="label-xs ml-1">Entity Name</label>
                  <input 
                    type="text" 
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="e.g. Al-Falah Trading Co."
                    className="w-full bg-slate-950 border border-bento-border/30 rounded-2xl py-4 px-6 text-sm text-white focus:ring-4 focus:ring-emerald-500/10 focus:border-emerald-500 outline-none transition-all"
                  />
                </div>

                <div className="space-y-2">
                  <label className="label-xs ml-1">Official Email</label>
                  <input 
                    type="email" 
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="contact@entity.com"
                    className="w-full bg-slate-950 border border-bento-border/30 rounded-2xl py-4 px-6 text-sm text-white focus:ring-4 focus:ring-emerald-500/10 focus:border-emerald-500 outline-none transition-all"
                  />
                </div>

                <div className="space-y-2">
                  <label className="label-xs ml-1">Risk Assessment Tier</label>
                  <div className="grid grid-cols-3 gap-3">
                    {['Low', 'Medium', 'High'].map((r) => (
                      <button
                        key={r}
                        onClick={() => setRisk(r as any)}
                        className={cn(
                          "py-3 rounded-xl text-[10px] font-bold uppercase transition-all border",
                          risk === r 
                            ? "bg-emerald-600 text-white border-emerald-500 shadow-lg" 
                            : "bg-slate-950 text-slate-500 border-bento-border/20 hover:border-slate-700"
                        )}
                      >
                        {r}
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              <button 
                onClick={handleOnboard}
                disabled={!name || !email}
                className="w-full mt-10 bg-emerald-600 text-white rounded-3xl py-5 font-black uppercase tracking-widest text-sm hover:bg-emerald-500 disabled:opacity-20 transition-all shadow-xl active:scale-95"
              >
                Initiate Verification
              </button>
            </div>
          )}

          {step === 'VERIFYING' && (
            <div className="p-16 text-center space-y-8">
              <div className="relative w-24 h-24 mx-auto">
                <Loader2 className="w-24 h-24 text-emerald-500 animate-spin opacity-20" />
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="w-12 h-12 bg-emerald-500 rounded-2xl flex items-center justify-center animate-pulse">
                    <ShieldCheck className="w-7 h-7 text-white" />
                  </div>
                </div>
              </div>
              <div className="space-y-2">
                <h3 className="text-2xl font-bold text-white tracking-tight">Gatekeeper Screening</h3>
                <p className="text-slate-500 text-sm max-w-[260px] mx-auto leading-relaxed">Checking Shariah blocklists and verifying entity legitimacy across global nodes.</p>
              </div>
              <div className="space-y-3 font-mono text-[10px] uppercase tracking-[0.3em] text-emerald-500/60">
                <p className="animate-pulse">KYC Authenticating...</p>
                <p className="animate-pulse delay-100">AML Vector Scan...</p>
                <p className="animate-pulse delay-200">Shariah Profile Map...</p>
              </div>
            </div>
          )}

          {step === 'SUCCESS' && (
            <div className="p-16 text-center space-y-6">
              <div className="w-20 h-20 bg-emerald-500 rounded-full flex items-center justify-center mx-auto shadow-[0_0_40px_rgba(16,185,129,0.4)]">
                <CheckCircle2 className="w-12 h-12 text-white" />
              </div>
              <div>
                <h3 className="text-2xl font-bold text-white tracking-tight">Access Granted</h3>
                <p className="text-slate-500 text-sm">Entity hash deployed to Shariah Sentinel ledger. Access to Islamic Finance suites remains active.</p>
              </div>
              <div className="pt-4">
                 <div className="inline-flex items-center gap-2 bg-slate-950 px-4 py-2 rounded-full border border-emerald-500/30">
                    <Fingerprint className="w-3 h-3 text-emerald-500" />
                    <span className="text-[10px] font-mono text-emerald-400 font-bold uppercase tracking-widest leading-none">NODE-PROFILE-VERIFIED</span>
                 </div>
              </div>
            </div>
          )}
        </motion.div>
      </div>
    </AnimatePresence>
  );
}
