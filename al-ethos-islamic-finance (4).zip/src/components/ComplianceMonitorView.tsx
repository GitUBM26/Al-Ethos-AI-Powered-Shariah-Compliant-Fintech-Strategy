import React, { useState, useEffect } from 'react';
import { 
  ShieldCheck, 
  ShieldAlert, 
  Activity, 
  Terminal, 
  Cpu, 
  Database,
  Lock,
  Zap,
  Globe
} from 'lucide-react';
import { cn } from '../lib/utils';
import { motion, AnimatePresence } from 'motion/react';

interface Event {
  id: string;
  timestamp: string;
  type: 'INTERCEPT' | 'AUDIT' | 'COMMIT' | 'ALERT';
  message: string;
  source: string;
  severity: 'low' | 'medium' | 'high';
}

export function ComplianceMonitorView() {
  const [events, setEvents] = useState<Event[]>([]);
  const [nodeLoad, setNodeLoad] = useState(42);

  useEffect(() => {
    const initialEvents: Event[] = [
      { id: '1', timestamp: '09:41:12', type: 'INTERCEPT', message: 'Incoming RAW transaction payload from Dubai-01', source: 'Veea Edge', severity: 'low' },
      { id: '2', timestamp: '09:41:13', type: 'AUDIT', message: 'Gemini reasoning executing: AAOIFI Compliance Check', source: 'Lobstertrap Engine', severity: 'medium' },
      { id: '3', timestamp: '09:41:15', type: 'COMMIT', message: 'Protocol Hash written to Distributed Ledger', source: 'Chain Node AE-44', severity: 'low' },
    ];
    setEvents(initialEvents);

    const interval = setInterval(() => {
      const types: Event['type'][] = ['INTERCEPT', 'AUDIT', 'COMMIT', 'ALERT'];
      const messages = [
        'Heartbeat: Shariah Board Fatwa DB Sync Complete',
        'Payload validation: Musharakah Ratio Consistency Check',
        'AI Guard: Riba-contamination scan results: 0%',
        'Node Alert: Late payment fee redirected to charity node',
        'Blockchain: Block #882,101 confirmed by 128 nodes'
      ];
      
      const newEvent: Event = {
        id: Math.random().toString(),
        timestamp: new Date().toLocaleTimeString('en-GB'),
        type: types[Math.floor(Math.random() * types.length)],
        message: messages[Math.floor(Math.random() * messages.length)],
        source: ['Dubai-North', 'London-Center', 'Singapore-Vault'][Math.floor(Math.random() * 3)],
        severity: Math.random() > 0.8 ? 'high' : 'low'
      };

      setEvents(prev => [newEvent, ...prev.slice(0, 15)]);
      setNodeLoad(prev => Math.max(30, Math.min(95, prev + (Math.random() * 10 - 5))));
    }, 4000);

    return () => clearInterval(interval);
  }, []);

  return (
    <div className="space-y-6 max-w-7xl mx-auto">
      <header className="flex justify-between items-end">
        <div>
          <h2 className="text-3xl font-sans font-black text-white tracking-tight">Veea Execution Layer</h2>
          <p className="text-slate-500 text-sm mt-1">Real-time Shariah Guard Interception & Automated Auditing.</p>
        </div>
        <div className="flex gap-4">
           <div className="px-4 py-2 bento-card flex items-center gap-3">
             <div className="text-[10px] uppercase font-bold text-slate-500 tracking-widest">Global Load</div>
             <div className="w-24 h-1.5 bg-slate-900 rounded-full overflow-hidden border border-slate-800">
               <motion.div 
                 animate={{ width: `${nodeLoad}%` }}
                 className="bg-emerald-500 h-full shadow-[0_0_8px_rgba(16,185,129,0.5)]" 
               />
             </div>
             <span className="text-xs font-mono text-emerald-500">{nodeLoad.toFixed(1)}%</span>
           </div>
        </div>
      </header>

      <div className="grid grid-cols-12 gap-6 h-[600px]">
        {/* Live Interception Log */}
        <div className="col-span-8 bento-card !p-0 overflow-hidden flex flex-col bg-slate-950/40 border-bento-border/20">
          <div className="p-4 bg-slate-900/80 border-b border-bento-border/20 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Terminal className="w-4 h-4 text-emerald-500" />
              <span className="text-[10px] font-bold text-white uppercase tracking-[0.2em]">Live Interception Stream</span>
            </div>
            <div className="flex items-center gap-1.5 text-rose-500 animate-pulse">
              <span className="w-2 h-2 bg-rose-500 rounded-full" />
              <span className="text-[10px] font-bold uppercase tracking-widest">Encrypted Stream</span>
            </div>
          </div>
          
          <div className="flex-1 overflow-y-auto p-4 space-y-2 font-mono text-[11px] custom-scrollbar">
            <AnimatePresence initial={false}>
              {events.map((event) => (
                <motion.div
                  key={event.id}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  className={cn(
                    "p-3 rounded-lg border flex items-start gap-4 transition-colors",
                    event.severity === 'high' 
                      ? "bg-rose-500/10 border-rose-500/30 text-rose-200" 
                      : "bg-slate-900/30 border-slate-800/50 text-slate-400"
                  )}
                >
                  <span className="text-slate-600 shrink-0">{event.timestamp}</span>
                  <span className={cn(
                    "px-1.5 py-0.5 rounded text-[9px] font-bold uppercase shrink-0",
                    event.type === 'ALERT' ? "bg-rose-500 text-white" : "bg-slate-800 text-slate-300"
                  )}>
                    {event.type}
                  </span>
                  <span className="flex-1">{event.message}</span>
                  <span className="text-[10px] text-slate-600 font-bold uppercase tracking-widest">{event.source}</span>
                </motion.div>
              ))}
            </AnimatePresence>
          </div>
        </div>

        {/* Node Visualization / Map Placeholder */}
        <div className="col-span-4 flex flex-col gap-6">
          <div className="flex-1 bento-card relative overflow-hidden flex flex-col items-center justify-center text-center">
            <div className="absolute inset-0 opacity-10">
              <Globe className="w-full h-full text-emerald-500" />
            </div>
            <div className="relative z-10 space-y-4">
              <div className="w-20 h-20 bg-slate-900 border-2 border-emerald-500/20 rounded-full flex items-center justify-center mx-auto shadow-[0_0_30px_rgba(16,185,129,0.2)]">
                 <ShieldCheck className="w-10 h-10 text-emerald-500" />
              </div>
              <div>
                <h3 className="text-lg font-bold text-white">Shariah Guard Active</h3>
                <p className="text-xs text-slate-500 px-8">128 Validator Nodes synced with Al-Ethos Board Fatwas.</p>
              </div>
            </div>
          </div>

          <div className="h-48 bento-card bg-gradient-to-br from-emerald-950/40 to-slate-950 flex flex-col justify-between">
            <div>
              <span className="label-xs text-emerald-400">Security Invariant</span>
              <h4 className="text-sm font-bold text-white mt-1">Atomicity Check: ENABLED</h4>
            </div>
            <p className="text-[10px] text-slate-400 leading-relaxed">
              Veea protocol ensures that no transaction is committed to the ledger without a 99.9% Shariah confidence score from the Gemini reasoning layer.
            </p>
            <div className="flex gap-2 text-[9px] font-bold uppercase tracking-widest">
              <span className="flex items-center gap-1 text-emerald-500"><Zap className="w-3 h-3" /> FIPS-140-2</span>
              <span className="flex items-center gap-1 text-emerald-500"><Lock className="w-3 h-3" /> AES-256</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
