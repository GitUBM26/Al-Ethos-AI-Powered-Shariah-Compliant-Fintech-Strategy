import React from 'react';
import { 
  History,
  LayoutDashboard, 
  Users, 
  ShoppingBag, 
  Database, 
  ShieldCheck, 
  ArrowRightLeft,
  Settings,
  Bell,
  Share2,
  Target
} from 'lucide-react';
import { cn } from '../lib/utils';

interface SidebarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
}

const navItems = [
  { id: 'dashboard', label: 'Overview', icon: LayoutDashboard },
  { id: 'onboarding', label: 'Customers', icon: Users },
  { id: 'products', label: 'Products', icon: ShoppingBag },
  { id: 'ledger', label: 'Blockchain Ledger', icon: Database },
  { id: 'compliance', label: 'Execution Layer', icon: ShieldCheck },
  { id: 'advisor', label: 'Shariah Advisor', icon: Bell },
  { id: 'architecture', label: 'Tech Stack', icon: Share2 },
  { id: 'presentation', label: 'Pitch Deck', icon: Target },
  { id: 'transactions', label: 'History', icon: History },
];

export function Sidebar({ activeTab, setActiveTab }: SidebarProps) {
  return (
    <div className="w-68 bg-slate-950 border-r border-bento-border/20 flex flex-col h-screen text-slate-400">
      <div className="p-8 flex items-center gap-4">
        <div className="w-10 h-10 bg-emerald-600 rounded-xl flex items-center justify-center shadow-[0_0_15px_rgba(16,185,129,0.3)]">
          <ShieldCheck className="text-white w-6 h-6" />
        </div>
        <div>
          <h1 className="font-sans font-black text-xl text-white tracking-tight leading-none">AL-ETHOS</h1>
          <p className="text-[10px] text-slate-500 uppercase tracking-widest font-bold mt-1">Shariah Sentinel</p>
        </div>
      </div>
      
      <nav className="flex-1 px-4 py-4 space-y-2 overflow-y-auto custom-scrollbar">
        {navItems.map((item) => (
          <button
            key={item.id}
            onClick={() => setActiveTab(item.id)}
            className={cn(
              "w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-semibold transition-all duration-300 group",
              activeTab === item.id 
                ? "bg-emerald-500/10 text-emerald-400 shadow-[inset_0_1px_0_0_rgba(255,255,255,0.05)] border border-emerald-500/20" 
                : "hover:bg-slate-900/50 hover:text-slate-200"
            )}
          >
            <item.icon className={cn("w-5 h-5 transition-transform duration-300 group-hover:scale-110", activeTab === item.id ? "text-emerald-400" : "text-slate-600")} />
            {item.label}
          </button>
        ))}
      </nav>

      <div className="p-6 border-t border-bento-border/20 space-y-4">
        <div className="bg-slate-900/40 rounded-2xl p-5 border border-bento-border/10">
          <div className="flex items-center justify-between mb-3">
            <span className="text-[10px] font-bold text-emerald-500 uppercase tracking-[0.2em]">Live Nodes</span>
            <div className="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-pulse shadow-[0_0_8px_rgba(16,185,129,0.5)]" />
          </div>
          <div className="space-y-1.5">
            <div className="flex justify-between text-[10px] font-mono">
              <span className="text-slate-500">Node ID</span>
              <span className="text-slate-300">AE-882-QX</span>
            </div>
            <div className="flex justify-between text-[10px] font-mono">
              <span className="text-slate-500">Sync Status</span>
              <span className="text-emerald-400">100% Secure</span>
            </div>
          </div>
        </div>
        <button className="flex items-center gap-2 text-xs font-bold text-slate-500 hover:text-white transition-colors w-full px-2 py-2">
          <Settings className="w-4 h-4" />
          Configuration
        </button>
      </div>
    </div>
  );
}
