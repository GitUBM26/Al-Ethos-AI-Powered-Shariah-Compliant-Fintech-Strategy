import React, { useState, useEffect } from 'react';
import { Product, Transaction, ContractStatus, ProductType } from '../types';
import { 
  X, 
  ShieldCheck, 
  Fingerprint, 
  Cpu, 
  AlertTriangle,
  Loader2,
  CheckCircle2
} from 'lucide-react';
import { cn, formatCurrency } from '../lib/utils';
import { monitorCompliance } from '../services/veeaMonitor';
import { motion, AnimatePresence } from 'motion/react';

interface TransactionModalProps {
  product: Product | null;
  onClose: () => void;
  onCommit: (transaction: Transaction, advice: string, status: 'PASSED' | 'WARNING' | 'FAILED') => void;
}

export function TransactionModal({ product, onClose, onCommit }: TransactionModalProps) {
  const [step, setStep] = useState<'DETAILS' | 'MONITORING' | 'RESULT'>('DETAILS');
  const [amount, setAmount] = useState(product?.minAmount || 0);
  const [auditResult, setAuditResult] = useState<{ status: 'PASSED' | 'WARNING' | 'FAILED', advice: string, score: number } | null>(null);

  useEffect(() => {
    if (product) setAmount(product.minAmount);
  }, [product]);

  const handleApply = async () => {
    setStep('MONITORING');
    
    const mockTx: Transaction = {
      id: `tx-${Math.random().toString(36).substr(2, 9)}`,
      customerId: 'c-001',
      productId: product!.id,
      amount: amount,
      timestamp: Date.now(),
      status: ContractStatus.PENDING,
      type: 'INITIAL',
    };

    const result = await monitorCompliance(mockTx, product!.type);
    setAuditResult(result);
    setStep('RESULT');
  };

  if (!product) return null;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-sm">
        <motion.div 
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 0.95 }}
          className="bg-slate-900 w-full max-w-lg rounded-[2.5rem] overflow-hidden shadow-[0_0_50px_rgba(0,0,0,0.5)] border border-bento-border/30 relative backdrop-blur-xl"
        >
          <button onClick={onClose} className="absolute top-6 right-6 p-2 text-slate-500 hover:text-white transition-colors bg-slate-950/50 rounded-xl">
            <X className="w-5 h-5" />
          </button>

          {step === 'DETAILS' && (
            <div className="p-10">
              <div className="flex items-center gap-4 mb-8">
                <div className="p-3 bg-emerald-500/10 text-emerald-500 rounded-2xl border border-emerald-500/20">
                  <Fingerprint className="w-7 h-7" />
                </div>
                <div>
                  <h3 className="font-bold text-white text-lg">Contract Initialization</h3>
                  <p className="text-[10px] text-emerald-500 font-mono tracking-widest uppercase font-bold">SECURE NODE SESSION: {Math.random().toString(16).slice(2, 10).toUpperCase()}</p>
                </div>
              </div>

              <div className="space-y-6">
                <div className="bg-slate-950/80 p-5 rounded-3xl border border-bento-border/20">
                   <span className="label-xs">Asset Instrument</span>
                  <p className="font-bold text-white text-lg">{product.name}</p>
                  <p className="text-xs text-slate-500 italic mt-1 leading-relaxed">Structured under {product.shariahBase} protocol.</p>
                </div>

                <div className="space-y-2">
                  <label className="label-xs ml-1">Capital Investment / Finance Amount</label>
                  <div className="relative group">
                    <span className="absolute left-5 top-1/2 -translate-y-1/2 text-emerald-500 font-black text-lg">$</span>
                    <input 
                      type="number" 
                      value={amount}
                      onChange={(e) => setAmount(Number(e.target.value))}
                      className="w-full bg-slate-950 border border-bento-border/30 rounded-3xl py-5 pl-10 pr-6 font-mono font-bold text-xl text-white focus:outline-none focus:ring-4 focus:ring-emerald-500/10 focus:border-emerald-500 transition-all group-hover:border-slate-700"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="p-4 bg-slate-950/50 rounded-2xl border border-bento-border/10">
                    <span className="label-xs">PSR / Expected Profit</span>
                    <p className="text-sm font-bold text-white font-mono">{product.expectedProfitRate ? `${product.expectedProfitRate}%` : 'Variable Lease'}</p>
                  </div>
                  <div className="p-4 bg-slate-950/50 rounded-2xl border border-bento-border/10">
                    <span className="label-xs">Contract Cycle</span>
                    <p className="text-sm font-bold text-white font-mono">{product.tenureMonths} Months</p>
                  </div>
                </div>
              </div>

              <button 
                onClick={handleApply}
                disabled={amount < product.minAmount}
                className="w-full mt-10 bg-emerald-600 text-white rounded-3xl py-5 font-black uppercase tracking-widest text-sm hover:bg-emerald-500 disabled:opacity-30 disabled:cursor-not-allowed transition-all shadow-[0_10px_25px_-5px_rgba(16,185,129,0.4)] active:scale-[0.98]"
              >
                Forward to Shariah Guard
              </button>
            </div>
          )}

          {step === 'MONITORING' && (
            <div className="p-16 text-center space-y-8">
              <div className="relative w-24 h-24 mx-auto">
                <Loader2 className="w-24 h-24 text-emerald-500 animate-spin opacity-20" />
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="w-12 h-12 bg-emerald-500 rounded-2xl flex items-center justify-center animate-pulse shadow-[0_0_30px_rgba(16,185,129,0.5)]">
                    <ShieldCheck className="w-7 h-7 text-white" />
                  </div>
                </div>
              </div>
              <div className="space-y-2">
                <h3 className="text-2xl font-bold text-white tracking-tight">Veea (Lobstertrap) Is Scanning</h3>
                <p className="text-slate-500 text-sm max-w-[300px] mx-auto leading-relaxed">Auditing transaction ontology against AAOIFI international Shariah standards.</p>
              </div>
              <div className="space-y-3 font-mono text-[10px] uppercase tracking-[0.3em] text-emerald-500/60">
                <p className="animate-pulse">Analyzing Riba Vectors...</p>
                <p className="animate-pulse delay-100">Validating Asset Lexicon...</p>
                <p className="animate-pulse delay-200">Executing Risk-Share Calc...</p>
              </div>
            </div>
          )}

          {step === 'RESULT' && auditResult && (
            <div className="p-10">
              <div className="text-center mb-10">
                <div className={cn(
                  "w-20 h-20 rounded-3xl flex items-center justify-center mx-auto mb-6 shadow-2xl",
                  auditResult.status === 'PASSED' ? "bg-emerald-500 text-white shadow-emerald-500/20" : "bg-rose-600 text-white shadow-rose-600/20"
                )}>
                  {auditResult.status === 'PASSED' ? <CheckCircle2 className="w-12 h-12" /> : <AlertTriangle className="w-12 h-12" />}
                </div>
                <span className="label-xs mb-0">Analysis Verdict</span>
                <h3 className={cn(
                  "text-3xl font-black uppercase tracking-tighter mb-2",
                  auditResult.status === 'PASSED' ? "text-emerald-400" : "text-rose-500"
                )}>Audit {auditResult.status}</h3>
                
                <div className="flex items-center justify-center gap-3 mt-4">
                   <div className="w-40 bg-slate-950 h-1.5 rounded-full overflow-hidden border border-slate-800">
                     <motion.div 
                       initial={{ width: 0 }}
                       animate={{ width: `${auditResult.score}%` }}
                       transition={{ duration: 1.5, ease: "easeOut" }}
                       className={cn("h-full", auditResult.status === 'PASSED' ? "bg-emerald-500" : "bg-rose-500")}
                     />
                   </div>
                   <span className="text-[10px] font-bold text-slate-500 font-mono">{(auditResult.score).toFixed(1)}% CONFIDENCE</span>
                </div>
              </div>

              <div className="bg-slate-950 rounded-[2rem] p-8 text-slate-300 font-mono text-[11px] leading-relaxed border border-bento-border/20 mb-8 shadow-inner relative group">
                <div className="flex items-center gap-2 mb-4">
                  <Cpu className="w-4 h-4 text-emerald-500" />
                  <span className="text-[10px] font-bold text-white uppercase tracking-[0.2em]">Guard Engine Advice</span>
                </div>
                <div className="opacity-80 group-hover:opacity-100 transition-opacity">
                  {auditResult.advice}
                </div>
              </div>

              <div className="flex flex-col gap-4">
                <button 
                  onClick={() => {
                    const tx: Transaction = {
                      id: `tx-${Math.random().toString(36).substr(2, 9)}`,
                      customerId: 'c-001',
                      productId: product!.id,
                      amount: amount,
                      timestamp: Date.now(),
                      status: auditResult.status === 'PASSED' ? ContractStatus.ACTIVE : ContractStatus.FLAGGED,
                      type: 'INITIAL',
                    };
                    onCommit(tx, auditResult.advice, auditResult.status);
                  }}
                  className={cn(
                    "w-full py-5 rounded-3xl font-black uppercase tracking-widest text-sm shadow-2xl transition-all active:scale-[0.98]",
                    auditResult.status === 'PASSED' ? "bg-emerald-600 hover:bg-emerald-500 text-white" : "bg-slate-800 hover:bg-slate-700 text-white"
                  )}
                >
                  {auditResult.status === 'PASSED' ? 'Commit to Shariah Ledger' : 'Escalate to Board'}
                </button>
                <button onClick={onClose} className="py-2 text-slate-500 font-bold text-[10px] uppercase tracking-widest hover:text-white transition-colors">
                  Discard Draft Contract
                </button>
              </div>
            </div>
          )}
        </motion.div>
      </div>
    </AnimatePresence>
  );
}
