import React from 'react';
import { 
  Database, 
  Cpu, 
  ShieldCheck, 
  Lock, 
  Share2, 
  Layers,
  ArrowRight
} from 'lucide-react';
import { cn } from '../lib/utils';

export function ArchitectureView() {
  return (
    <div className="max-w-6xl mx-auto space-y-12 py-8">
      <header className="text-center space-y-4">
        <h2 className="text-4xl font-sans font-black text-white tracking-widest uppercase">System Architecture</h2>
        <div className="flex justify-center flex-wrap gap-4">
           <span className="px-3 py-1 bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 rounded-full text-[10px] font-black tracking-widest uppercase">Hybrid Web3 Framework</span>
           <span className="px-3 py-1 bg-blue-500/10 border border-blue-500/20 text-blue-400 rounded-full text-[10px] font-black tracking-widest uppercase">Gemini Shariah Reasoning</span>
           <span className="px-3 py-1 bg-amber-500/10 border border-amber-500/20 text-amber-500 rounded-full text-[10px] font-black tracking-widest uppercase">Veea-Lobstertrap Protocol</span>
        </div>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8 relative">
        {/* Connection lines (simplified) */}
        <div className="hidden md:block absolute top-[120px] left-[30%] w-[10%] h-px bg-emerald-500/20 border-t border-dashed" />
        <div className="hidden md:block absolute top-[120px] left-[60%] w-[10%] h-px bg-emerald-500/20 border-t border-dashed" />

        {/* Column 1: The Guard */}
        <div className="bento-card bg-slate-900 shadow-[0_0_40px_rgba(31,41,55,0.5)] flex flex-col items-center text-center p-8 border-t-4 border-t-blue-500">
           <div className="w-16 h-16 bg-blue-500/10 rounded-2xl flex items-center justify-center mb-6">
             <Layers className="w-8 h-8 text-blue-400" />
           </div>
           <h3 className="text-xl font-bold text-white mb-2">Veea Guard Layer</h3>
           <p className="text-xs text-slate-400 leading-relaxed mb-6">
             Standard Web2 transactions are intercepted at the edge. The Veea protocol sanitizes payloads before AI processing.
           </p>
           <ul className="text-left w-full space-y-2 text-[10px] text-slate-500 font-mono">
             <li className="flex gap-2 items-center"><ArrowRight className="w-3 h-3 text-blue-500" /> Payload Interception</li>
             <li className="flex gap-2 items-center"><ArrowRight className="w-3 h-3 text-blue-500" /> Shariah-Ontology Map</li>
             <li className="flex gap-2 items-center"><ArrowRight className="w-3 h-3 text-blue-500" /> AAOIFI Standard Injector</li>
           </ul>
        </div>

        {/* Column 2: The Brain */}
        <div className="bento-card bg-emerald-950/20 shadow-[0_0_50px_rgba(16,185,129,0.15)] flex flex-col items-center text-center p-8 border-t-4 border-t-emerald-500">
           <div className="w-16 h-16 bg-emerald-500/10 rounded-2xl flex items-center justify-center mb-6 ring-4 ring-emerald-500/5 animate-pulse">
             <Cpu className="w-8 h-8 text-emerald-500" />
           </div>
           <h3 className="text-xl font-bold text-white mb-2">Gemini Reasoning</h3>
           <p className="text-xs text-slate-400 leading-relaxed mb-6">
             Multimodal analysis of contract clauses. Uses chain-of-thought to verify risk-sharing ratios and profit distributions.
           </p>
           <div className="w-full bg-slate-950/80 rounded-xl p-4 border border-emerald-500/20 text-emerald-400 font-mono text-[9px] text-left">
             <code>PROMPT: Validate(Musharakah_Terms)<br/>ENGINE: Veea-Lobstertrap-v2<br/>STATUS: Reasoning...</code>
           </div>
        </div>

        {/* Column 3: The Ledger */}
        <div className="bento-card bg-slate-900 flex flex-col items-center text-center p-8 border-t-4 border-t-amber-500">
           <div className="w-16 h-16 bg-amber-500/10 rounded-2xl flex items-center justify-center mb-6">
             <Database className="w-8 h-8 text-amber-500" />
           </div>
           <h3 className="text-xl font-bold text-white mb-2">Immutable Ledger</h3>
           <p className="text-xs text-slate-400 leading-relaxed mb-6">
             Only transactions with a 99%+ compliance score are hashed and committed to the distributed blockchain.
           </p>
           <div className="grid grid-cols-2 gap-2 w-full">
             <div className="bg-slate-950 p-2 rounded-lg border border-slate-800 text-[9px] text-slate-500 font-mono">HASH: SHA-256</div>
             <div className="bg-slate-950 p-2 rounded-lg border border-slate-800 text-[9px] text-slate-500 font-mono">NODES: DISTRIBUTED</div>
           </div>
        </div>
      </div>

      <div className="bento-card bg-slate-950/50 p-10 mt-12 border-bento-border/20">
         <div className="flex flex-col md:flex-row gap-8 items-center">
            <div className="flex-1 space-y-4">
              <h3 className="text-2xl font-bold text-white tracking-tight">The Labstertrap Protocol</h3>
              <p className="text-sm text-slate-400 leading-relaxed">
                By combining **Immutable Ledgers** with **Generative AI Monitoring**, we solve the governance gap in Islamic Finance. Every finance application, every payment, and every contract is audited live—preventing non-compliant leakage before it happens.
              </p>
              <div className="flex gap-4">
                 <div className="flex items-center gap-2">
                   <ShieldCheck className="w-5 h-5 text-emerald-500" />
                   <span className="text-[10px] font-bold text-slate-300 uppercase tracking-widest">AAOIFI Compliant</span>
                 </div>
                 <div className="flex items-center gap-2">
                   <Lock className="w-5 h-5 text-emerald-500" />
                   <span className="text-[10px] font-bold text-slate-300 uppercase tracking-widest">ISO 27001 Secure</span>
                 </div>
              </div>
            </div>
            <div className="w-full md:w-64 h-64 bg-slate-900 rounded-[3rem] border border-bento-border/30 overflow-hidden relative group">
               <div className="absolute inset-0 bg-gradient-to-t from-emerald-500/20 to-transparent opacity-50" />
               <div className="absolute inset-0 flex items-center justify-center">
                  <Share2 className="w-32 h-32 text-slate-800 group-hover:text-emerald-500/20 transition-colors duration-1000" />
               </div>
            </div>
         </div>
      </div>
    </div>
  );
}
