import React from 'react';
import { PRODUCTS } from '../constants';
import { Product, ProductType } from '../types';
import { 
  Car, 
  Home, 
  TrendingUp, 
  Briefcase, 
  ShieldCheck, 
  Info,
  ChevronRight
} from 'lucide-react';
import { cn, formatCurrency } from '../lib/utils';
import { motion } from 'motion/react';

interface ProductCatalogueProps {
  onSelect: (product: Product) => void;
}

const typeIcons: Record<ProductType, any> = {
  [ProductType.IJARAH]: Car,
  [ProductType.MUSHARAKAH]: Home,
  [ProductType.MUDARABA]: TrendingUp,
  [ProductType.WAKALAH]: Briefcase,
};

export function ProductCatalogue({ onSelect }: ProductCatalogueProps) {
  return (
    <div className="space-y-6 max-w-7xl mx-auto">
      <header>
        <h2 className="text-3xl font-sans font-bold text-white tracking-tight">Financial Products</h2>
        <p className="text-slate-500 text-sm mt-1">Shariah-governed digital assets and financing portfolios.</p>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {PRODUCTS.map((product, idx) => {
          const Icon = typeIcons[product.type];
          return (
            <motion.div
              key={product.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: idx * 0.1 }}
              whileHover={{ scale: 1.02 }}
              className="bento-card group cursor-pointer flex flex-col justify-between hover:border-emerald-500/50"
              onClick={() => onSelect(product)}
            >
              <div>
                <div className="flex justify-between items-start mb-6">
                  <div className="p-4 bg-slate-900 border border-bento-border/30 rounded-2xl text-emerald-500 group-hover:bg-emerald-600 group-hover:text-white transition-all shadow-lg">
                    <Icon className="w-6 h-6" />
                  </div>
                  <div className="text-[9px] font-bold text-slate-600 font-mono tracking-[0.2em] uppercase">
                    REG: {product.id.split('-').pop()}
                  </div>
                </div>
                
                <h3 className="text-xl font-bold text-white mb-2">{product.name}</h3>
                <p className="text-slate-400 text-xs leading-relaxed mb-6 line-clamp-2">{product.description}</p>
                
                <div className="space-y-3 mb-8">
                  <div className="flex items-center gap-2 text-xs text-slate-300 bg-slate-900/50 p-2 rounded-lg border border-slate-800/50">
                    <ShieldCheck className="w-3.5 h-3.5 text-emerald-500" />
                    <span>Basis: <span className="text-white font-semibold">{product.shariahBase}</span></span>
                  </div>
                  <div className="flex items-center gap-2 text-xs text-slate-300 bg-slate-900/50 p-2 rounded-lg border border-slate-800/50">
                    <Info className="w-3.5 h-3.5 text-blue-400" />
                    <span>Tenure: <span className="text-white font-semibold">{product.tenureMonths} Months</span></span>
                  </div>
                </div>
              </div>

              <div className="pt-6 border-t border-bento-border/20 flex items-center justify-between">
                <div>
                   <span className="label-xs mb-0.5">Asset Value</span>
                  <p className="text-xl font-bold text-emerald-400 font-mono">{formatCurrency(product.minAmount)}</p>
                </div>
                <button className="h-12 w-12 bg-slate-900 border border-bento-border/30 text-white rounded-2xl flex items-center justify-center group-hover:bg-emerald-600 group-hover:border-emerald-500 transition-all shadow-xl">
                  <ChevronRight className="w-5 h-5" />
                </button>
              </div>
            </motion.div>
          );
        })}
      </div>

      <div className="mt-12 bento-card bg-emerald-950/20 border-emerald-500/20 flex items-start gap-5 p-6">
        <div className="p-3 bg-emerald-500/10 text-emerald-500 rounded-2xl border border-emerald-500/20 shrink-0">
          <Info className="w-6 h-6" />
        </div>
        <div>
          <p className="text-md font-bold text-white mb-1">Corporate Shariah Structuring</p>
          <p className="text-sm text-slate-400 leading-relaxed">Our Shariah board can structure custom Musharakah or Ijarah frameworks for high-value enterprise assets. All bespoke contracts are automatically indexed on the Veea monitoring layer.</p>
        </div>
      </div>
    </div>
  );
}
