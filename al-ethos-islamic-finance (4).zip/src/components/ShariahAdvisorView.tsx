import React, { useState } from 'react';
import { 
  Send, 
  MessageSquare, 
  Cpu, 
  ShieldCheck, 
  Loader2,
  Sparkles,
  HelpCircle
} from 'lucide-react';
import { cn } from '../lib/utils';

const ADVISOR_PROMPT = `
You are the "Veea" (Lobstertrap) Shariah Advisor for Al-Ethos Islamic Finance.
Your task is to provide expert answers to customer questions about Islamic Finance.
All answers must strictly follow AAOIFI standards and emphasize the Lobstertrap monitoring protocol.

Guidelines:
1. Explain concepts simply (Mudaraba, Musharakah, Ijarah, Wakalah).
2. Highlight why Al-Ethos is different due to its Veea real-time blockchain monitoring.
3. Include a "Compliance Verdict" at the end of your response.
4. Keep it professional, scholarly, yet accessible.

Return JSON format: { "answer": "...", "verdict": "COMPLIANT | IN-REVIEW", "confidence": 0-100 }
`;

export function ShariahAdvisorView() {
  const [query, setQuery] = useState('');
  const [messages, setMessages] = useState<{ role: 'user' | 'ai', content: any }[]>([]);
  const [isLoading, setIsLoading] = useState(false);

  const handleAsk = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!query.trim() || isLoading) return;

    const userQuery = query;
    setMessages(prev => [...prev, { role: 'user', content: { answer: userQuery } }]);
    setQuery('');
    setIsLoading(true);

    try {
      const response = await fetch('/api/advisor', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          prompt: ADVISOR_PROMPT,
          query: userQuery,
        }),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Failed to get advice');
      }

      const { text } = await response.json();
      const jsonMatch = text.match(/\{.*\}/s);
      const data = jsonMatch ? JSON.parse(jsonMatch[0]) : { answer: text, verdict: 'COMPLIANT', confidence: 85 };
      
      setMessages(prev => [...prev, { role: 'ai', content: data }]);
    } catch (error: any) {
      console.error("Advisor Error:", error);
      const errorMessage = error.message.includes('API key') 
        ? "The Shariah Guard requires a valid API key to operate. Please ensure it is set in Settings > Secrets."
        : "The Shariah Guard is currently processing high volume. Please re-attempt your query in a moment.";
      
      setMessages(prev => [...prev, { role: 'ai', content: { answer: errorMessage, verdict: 'IN-REVIEW', confidence: 0 } }]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="space-y-6 max-w-4xl mx-auto h-[calc(100vh-160px)] flex flex-col">
      <header className="shrink-0">
        <h2 className="text-3xl font-sans font-black text-white tracking-tight">Shariah Advisor</h2>
        <p className="text-slate-500 text-sm mt-1">Real-time Shariah inquiry engine monitored by Veea Lobstertrap.</p>
      </header>

      <div className="flex-1 bento-card bg-slate-950/40 !p-0 overflow-hidden flex flex-col border-bento-border/20 shadow-2xl">
        {/* Messages Portal */}
        <div className="flex-1 overflow-y-auto p-8 space-y-6 custom-scrollbar">
          {messages.length === 0 && (
            <div className="h-full flex flex-col items-center justify-center text-center space-y-4 opacity-40">
              <div className="p-5 bg-slate-900 rounded-3xl border border-slate-800">
                <HelpCircle className="w-10 h-10 text-emerald-500" />
              </div>
              <div>
                <p className="text-white font-bold">Protocol Standby</p>
                <p className="text-xs text-slate-500 max-w-xs mx-auto mt-1">Ask a question about Diminishing Musharakah, Ijarah, or standard Shariah compliance rules.</p>
              </div>
            </div>
          )}

          {messages.map((msg, i) => (
            <div key={i} className={cn(
              "flex gap-4 animate-in fade-in slide-in-from-bottom-2",
              msg.role === 'user' ? "flex-row-reverse" : "flex-row"
            )}>
              <div className={cn(
                "w-10 h-10 rounded-2xl flex items-center justify-center shrink-0 border",
                msg.role === 'user' ? "bg-slate-900 border-slate-700" : "bg-emerald-600 border-emerald-500"
              )}>
                {msg.role === 'user' ? <MessageSquare className="w-5 h-5 text-slate-400" /> : <ShieldCheck className="w-5 h-5 text-white" />}
              </div>
              <div className={cn(
                "max-w-[80%] rounded-[2rem] p-6 text-sm font-medium shadow-xl",
                msg.role === 'user' ? "bg-slate-900 text-slate-100 rounded-tr-none" : "bg-white/[0.03] border border-white/10 text-slate-300 rounded-tl-none"
              )}>
                {msg.role === 'ai' ? (
                  <div className="space-y-4">
                    <p className="leading-relaxed">{msg.content.answer}</p>
                    <div className="pt-4 border-t border-white/10 flex items-center justify-between">
                       <div className="flex items-center gap-2">
                         <div className="px-2 py-0.5 bg-emerald-500/10 border border-emerald-500/20 rounded text-[9px] font-bold text-emerald-400">
                           {msg.content.verdict}
                         </div>
                         <div className="h-1 w-12 bg-slate-800 rounded-full overflow-hidden">
                           <div className="bg-emerald-500 h-full" style={{ width: `${msg.content.confidence}%` }} />
                         </div>
                       </div>
                       <span className="text-[10px] font-mono text-slate-500 uppercase tracking-widest">{msg.content.confidence}% CONSENSUS</span>
                    </div>
                  </div>
                ) : (
                  msg.content.answer
                )}
              </div>
            </div>
          ))}

          {isLoading && (
            <div className="flex gap-4 animate-pulse">
               <div className="w-10 h-10 rounded-2xl bg-emerald-600 flex items-center justify-center border border-emerald-500">
                <Loader2 className="w-5 h-5 text-white animate-spin" />
              </div>
              <div className="bg-white/[0.03] border border-white/10 rounded-[2rem] rounded-tl-none p-6 w-[200px]">
                <div className="h-4 bg-slate-800 rounded w-full mb-3" />
                <div className="h-4 bg-slate-800 rounded w-2/3" />
              </div>
            </div>
          )}
        </div>

        {/* Input Chamber */}
        <div className="p-6 bg-slate-900/50 border-t border-bento-border/20 backdrop-blur-md">
          <form onSubmit={handleAsk} className="relative flex items-center gap-4">
            <div className="relative flex-1">
              <input 
                type="text" 
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Ask our Veea Shariah Advisor..."
                className="w-full bg-slate-950 border border-bento-border/30 rounded-3xl py-4 pl-6 pr-14 text-sm text-white placeholder:text-slate-600 focus:ring-4 focus:ring-emerald-500/10 focus:border-emerald-500 outline-none transition-all"
              />
              <div className="absolute right-4 top-1/2 -translate-y-1/2 flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-emerald-500/30" />
              </div>
            </div>
            <button 
              type="submit"
              disabled={isLoading || !query.trim()}
              className="bg-emerald-600 h-14 w-14 rounded-full flex items-center justify-center text-white hover:bg-emerald-500 transition-all shadow-[0_0_20px_rgba(16,185,129,0.3)] disabled:opacity-30 active:scale-90 shrink-0"
            >
              {isLoading ? <Loader2 className="w-6 h-6 animate-spin" /> : <Send className="w-6 h-6" />}
            </button>
          </form>
          <div className="mt-3 flex justify-center gap-4">
            <p className="text-[10px] text-slate-500 font-bold uppercase tracking-widest flex items-center gap-1.5">
              <Cpu className="w-3 h-3" /> Veea Reasoning: Active
            </p>
            <p className="text-[10px] text-slate-500 font-bold uppercase tracking-widest flex items-center gap-1.5">
              <ShieldCheck className="w-3 h-3" /> Fatwa DB: Synced
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
