import React, { useState } from 'react';
import { INITIAL_CUSTOMERS } from '../constants';
import { 
  UserPlus, 
  Search, 
  Filter, 
  MoreHorizontal, 
  Mail, 
  ShieldCheck,
  Clock
} from 'lucide-react';
import { cn } from '../lib/utils';
import { OnboardingModal } from './OnboardingModal';

export function OnboardingView() {
  const [customers, setCustomers] = useState(INITIAL_CUSTOMERS);
  const [isModalOpen, setIsModalOpen] = useState(false);

  const handleAddCustomer = (newCustomer: any) => {
    setCustomers(prev => [newCustomer, ...prev]);
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto">
      <header className="flex justify-between items-end">
        <div>
          <h2 className="text-3xl font-sans font-bold text-white tracking-tight">Customer Repository</h2>
          <p className="text-slate-500 text-sm mt-1">Managing KYC, AML, and Shariah Profiles for the ecosystem.</p>
        </div>
        <button 
          onClick={() => setIsModalOpen(true)}
          className="bg-emerald-600 text-white px-5 py-2.5 rounded-2xl text-sm font-bold flex items-center gap-2 hover:bg-emerald-500 transition-all shadow-lg active:scale-95"
        >
          <UserPlus className="w-4 h-4" />
          Onboard Customer
        </button>
      </header>

      <div className="bento-card !p-0 overflow-hidden shadow-2xl">
        <div className="p-5 border-b border-bento-border/20 bg-slate-900/50 flex items-center justify-between">
          <div className="relative flex-1 max-w-md">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
            <input 
              type="text" 
              placeholder="Search via Name, Email or ID..." 
              className="w-full bg-slate-950 border border-bento-border/30 rounded-xl py-2.5 pl-11 pr-5 text-xs text-white focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 outline-none transition-all"
            />
          </div>
        </div>

        <table className="w-full border-collapse">
          <thead>
            <tr className="bg-slate-900/80 border-b border-bento-border/20 text-left">
              <th className="px-8 py-5 text-[10px] font-bold text-slate-500 uppercase tracking-widest">Customer Entity</th>
              <th className="px-8 py-5 text-[10px] font-bold text-slate-500 uppercase tracking-widest">Risk Index</th>
              <th className="px-8 py-5 text-[10px] font-bold text-slate-500 uppercase tracking-widest">Profile Status</th>
              <th className="px-8 py-5 text-[10px] font-bold text-slate-500 uppercase tracking-widest text-right">Action</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-bento-border/10">
            {customers.map((customer) => (
              <tr key={customer.id} className="hover:bg-white/[0.02] transition-colors cursor-pointer group">
                <td className="px-8 py-5">
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 rounded-2xl bg-slate-900 border border-slate-800 flex items-center justify-center font-bold text-slate-300 group-hover:bg-emerald-600/20 group-hover:text-emerald-400 group-hover:border-emerald-500/30 transition-all font-mono">
                      {customer.name.charAt(0)}
                    </div>
                    <div>
                      <p className="text-sm font-bold text-white mb-1 group-hover:text-emerald-400 transition-colors">{customer.name}</p>
                      <div className="flex items-center gap-1.5 text-xs text-slate-500">
                        <Mail className="w-3.5 h-3.5" />
                        {customer.email}
                      </div>
                    </div>
                  </div>
                </td>
                <td className="px-8 py-5">
                  <span className={cn(
                    "px-3 py-1 rounded-full text-[10px] font-bold border",
                    customer.riskProfile === 'Low' ? "bg-emerald-500/5 text-emerald-400 border-emerald-500/20" : "bg-amber-500/5 text-amber-500 border-amber-500/20"
                  )}>
                    {customer.riskProfile} Risk Profile
                  </span>
                </td>
                <td className="px-8 py-5">
                  <div className="flex items-center gap-2.5">
                    {customer.onboardingStatus === 'Completed' ? (
                      <ShieldCheck className="w-5 h-5 text-emerald-500" />
                    ) : (
                      <Clock className="w-5 h-5 text-amber-500 border-2 border-amber-500/20 rounded-full p-0.5" />
                    )}
                    <span className="text-xs font-bold text-slate-300 uppercase tracking-tight">{customer.onboardingStatus}</span>
                  </div>
                </td>
                <td className="px-8 py-5 text-right">
                  <button className="p-2 hover:bg-slate-900 rounded-xl transition-all text-slate-500 hover:text-white">
                    <MoreHorizontal className="w-5 h-5" />
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <OnboardingModal 
        isOpen={isModalOpen} 
        onClose={() => setIsModalOpen(false)} 
        onSuccess={handleAddCustomer} 
      />
    </div>
  );
}
