import React, { useState, useRef } from 'react';
import { 
  ChevronLeft, 
  ChevronRight, 
  Target, 
  Zap, 
  ShieldCheck, 
  Share2, 
  Cpu, 
  Database,
  Search,
  Globe,
  Lock,
  TrendingUp,
  BarChart3,
  Users,
  Download,
  Loader2
} from 'lucide-react';
import { cn } from '../lib/utils';
import { motion, AnimatePresence } from 'motion/react';
import { jsPDF } from 'jspdf';
import * as htmlToImage from 'html-to-image';

const SLIDES = [
  {
    title: "Al-Ethos",
    subtitle: "The Future of Shariah-Compliant Finance",
    tag: "Pitch Deck",
    content: "Bridging the gap between traditional Islamic Finance and the Modern Digital Economy through the Veea Lobstertrap Protocol.",
    icon: ShieldCheck,
    color: "emerald"
  },
  {
    title: "The Governance Gap",
    subtitle: "The Problem in Islamic Finance Today",
    tag: "Problem",
    content: "Manual audits are slow, reactive, and prone to human error. Riba-contamination and non-compliant clauses often slip through during execution, leading to trust deficits and financial leakage.",
    icon: Search,
    color: "rose"
  },
  {
    title: "Market Scope",
    subtitle: "A Multi-Trillion Dollar Opportunity",
    tag: "Market",
    content: "TAM: $4.5 Trillion (Global Islamic Finance Market). SAM: $1.2 Trillion (Digitally-active Islamic Banking Assets). The shift to Shariah-compliant digital assets is accelerating.",
    icon: Globe,
    color: "blue"
  },
  {
    title: "Veea Lobstertrap",
    subtitle: "AI-Powered Real-Time Guarding",
    tag: "Solution",
    content: "Our proprietary protocol intercepts raw transaction payloads at the edge. Every transaction is analyzed by Gemini Shariah Reasoning before it ever reaches the ledger.",
    icon: Zap,
    color: "blue"
  },
  {
    title: "Revenue Streams",
    subtitle: "Scalable Monetization Model",
    tag: "Business Model",
    content: "1. Institutional SaaS Subscription. 2. Per-Transaction Compliance Verification Fees. 3. Shariah Audit API Licensing for Fintechs.",
    icon: TrendingUp,
    color: "amber"
  },
  {
    title: "How It Works",
    subtitle: "The Execution Layer",
    tag: "Architecture",
    content: "1. Payload Interception → 2. Gemini AAOIFI Analysis → 3. Shariah Consensus → 4. Immutable Blockchain Hash. Total transparency, zero latency.",
    icon: Share2,
    color: "amber"
  },
  {
    title: "Core Ecosystem",
    subtitle: "Integrated Compliance Suites",
    tag: "Features",
    content: "An Interactive Shariah Advisor, Live Execution Monitor, Immutable Blockchain Ledger, and Automated Institutional Onboarding.",
    icon: Database,
    color: "emerald"
  },
  {
    title: "The Tech Stack",
    subtitle: "Engineered for Trust",
    tag: "Technology",
    content: "Built with React 18, Tailwind CSS, Gemini-1.5 AI Reasoning, and a custom Distributed Ledger Service (Veea-Net).",
    icon: Cpu,
    color: "purple"
  },
  {
    title: "Competitive Landscape",
    subtitle: "Our Unique Selling Proposition",
    tag: "Analysis",
    content: "Unlike legacy RegTech or manual audit firms, Al-Ethos offers 'Shariah-at-the-Edge'—real-time prevention rather than retrospective reporting.",
    icon: Users,
    color: "rose"
  },
  {
    title: "Strategic Impact",
    subtitle: "Global Scaling",
    tag: "Vision",
    content: "Al-Ethos turns compliance from a cost-center into a competitive advantage, enabling Islamic Banks to go globally digital with 100% automated confidence.",
    icon: Globe,
    color: "blue"
  }
];

export function PresentationView() {
  const [currentSlide, setCurrentSlide] = useState(0);
  const [isExporting, setIsExporting] = useState(false);
  const pdfContainerRef = useRef<HTMLDivElement>(null);

  const nextSlide = () => setCurrentSlide((prev) => (prev + 1) % SLIDES.length);
  const prevSlide = () => setCurrentSlide((prev) => (prev - 1 + SLIDES.length) % SLIDES.length);

  const downloadPDF = async () => {
    if (!pdfContainerRef.current) return;
    setIsExporting(true);
    
    try {
      const pdf = new jsPDF('l', 'px', [1024, 576]);
      const slides = pdfContainerRef.current.querySelectorAll('.pdf-slide');
      
      for (let i = 0; i < slides.length; i++) {
        // html-to-image is more robust for modern CSS (oklch/oklab) than html2canvas
        const imgData = await htmlToImage.toPng(slides[i] as HTMLElement, {
          quality: 1,
          pixelRatio: 2,
          backgroundColor: '#020617',
          style: {
            opacity: '1',
            visibility: 'visible',
            display: 'flex'
          }
        });
        
        const pdfWidth = pdf.internal.pageSize.getWidth();
        const pdfHeight = pdf.internal.pageSize.getHeight();
        
        if (i > 0) pdf.addPage();
        pdf.addImage(imgData, 'PNG', 0, 0, pdfWidth, pdfHeight);
      }
      
      pdf.save('Al-Ethos_Pitch_Deck.pdf');
    } catch (error) {
      console.error('PDF Export failed:', error);
    } finally {
      setIsExporting(false);
    }
  };

  const downloadCover = async () => {
    if (!pdfContainerRef.current) return;
    setIsExporting(true);
    try {
      const coverSlide = pdfContainerRef.current.querySelector('.pdf-slide') as HTMLElement;
      if (!coverSlide) return;

      const imgData = await htmlToImage.toPng(coverSlide, {
        quality: 1,
        pixelRatio: 3, // Higher quality for cover
        backgroundColor: '#020617',
        style: {
          opacity: '1',
          visibility: 'visible',
          display: 'flex'
        }
      });

      const link = document.createElement('a');
      link.download = 'Al-Ethos_Cover_Image.png';
      link.href = imgData;
      link.click();
    } catch (error) {
      console.error('Cover export failed:', error);
    } finally {
      setIsExporting(false);
    }
  };

  const slide = SLIDES[currentSlide];
  const Icon = slide.icon;

  return (
    <div className="h-[calc(100vh-160px)] flex flex-col items-center justify-start py-4 max-w-5xl mx-auto w-full overflow-y-auto custom-scrollbar">
      <div className="w-full flex items-center justify-between mb-6 shrink-0 h-10 px-2">
        <div className="flex gap-2">
          {SLIDES.map((_, i) => (
            <div 
              key={i} 
              className={cn(
                "h-1.5 transition-all duration-500 rounded-full",
                i === currentSlide ? "w-8 bg-emerald-500" : "w-3 bg-slate-800"
              )} 
            />
          ))}
        </div>
        <div className="flex items-center gap-4">
          <button
            onClick={downloadCover}
            disabled={isExporting}
            className="flex items-center gap-2 px-4 py-2 bg-emerald-600/10 hover:bg-emerald-600/20 disabled:opacity-50 text-emerald-500 rounded-full text-[10px] font-black uppercase tracking-widest transition-all border border-emerald-500/20"
          >
            {isExporting ? <Loader2 className="w-3 h-3 animate-spin" /> : <Download className="w-3 h-3" />}
            {isExporting ? "Exporting..." : "Download Cover (PNG)"}
          </button>
          <button
            onClick={downloadPDF}
            disabled={isExporting}
            className="flex items-center gap-2 px-4 py-2 bg-slate-800 hover:bg-slate-700 disabled:opacity-50 text-white rounded-full text-[10px] font-black uppercase tracking-widest transition-all border border-white/5"
          >
            {isExporting ? <Loader2 className="w-3 h-3 animate-spin" /> : <Download className="w-3 h-3" />}
            {isExporting ? "Export Deck (PDF)" : "Download PDF"}
          </button>
          <span className="text-[10px] font-mono text-slate-500 uppercase tracking-widest font-black">
            Slide {currentSlide + 1} of {SLIDES.length}
          </span>
        </div>
      </div>

      <div className="relative w-full flex-1">
        <AnimatePresence mode="wait">
          <motion.div
            key={currentSlide}
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            transition={{ duration: 0.4, ease: "easeOut" }}
            className="w-full h-full bento-card bg-slate-900 border-bento-border/30 overflow-hidden flex flex-col md:flex-row shadow-[0_0_100px_rgba(0,0,0,0.5)]"
          >
            {/* Visual Side */}
            <div className={cn(
              "md:w-2/5 p-12 flex flex-col items-center justify-center text-center relative",
              slide.color === 'emerald' && "bg-emerald-500/5",
              slide.color === 'rose' && "bg-rose-500/5",
              slide.color === 'blue' && "bg-blue-500/5",
              slide.color === 'amber' && "bg-amber-500/5",
              slide.color === 'purple' && "bg-purple-500/5",
            )}>
              <div className="absolute inset-0 opacity-10 flex items-center justify-center overflow-hidden">
                 <Icon className="w-96 h-96 blur-3xl" />
              </div>
              <div className={cn(
                "w-32 h-32 rounded-[2.5rem] flex items-center justify-center mb-8 relative z-10 shadow-2xl transition-all duration-700 hover:rotate-6",
                slide.color === 'emerald' && "bg-emerald-600 text-white",
                slide.color === 'rose' && "bg-rose-600 text-white",
                slide.color === 'blue' && "bg-blue-600 text-white",
                slide.color === 'amber' && "bg-amber-600 text-white",
                slide.color === 'purple' && "bg-purple-600 text-white",
              )}>
                <Icon className="w-16 h-16" />
              </div>
              <div className={cn(
                "px-4 py-1 rounded-full text-[10px] font-black tracking-[0.3em] uppercase mb-4",
                slide.color === 'emerald' && "bg-emerald-500/10 text-emerald-500",
                slide.color === 'rose' && "bg-rose-500/10 text-rose-500",
                slide.color === 'blue' && "bg-blue-500/10 text-blue-500",
                slide.color === 'amber' && "bg-amber-500/10 text-amber-500",
                slide.color === 'purple' && "bg-purple-500/10 text-purple-500",
              )}>
                {slide.tag}
              </div>
            </div>

            {/* Content Side */}
            <div className="md:w-3/5 p-16 flex flex-col justify-center bg-slate-950/40">
              <h2 className="text-5xl font-sans font-black text-white tracking-tight leading-tight mb-4">{slide.title}</h2>
              <h3 className="text-xl font-medium text-slate-400 mb-8">{slide.subtitle}</h3>
              <p className="text-lg text-slate-300 leading-relaxed font-light italic">
                "{slide.content}"
              </p>
              
              <div className="mt-12 flex gap-4">
                 <div className="flex items-center gap-2">
                   <Lock className="w-4 h-4 text-emerald-500" />
                   <span className="text-[9px] font-bold text-slate-500 uppercase tracking-widest">Protocol-Verified</span>
                 </div>
                 <div className="flex items-center gap-2">
                   <Target className="w-4 h-4 text-emerald-500" />
                   <span className="text-[9px] font-bold text-slate-500 uppercase tracking-widest">AAOIFI Compliant</span>
                 </div>
              </div>
            </div>
          </motion.div>
        </AnimatePresence>

        <div className="absolute -bottom-20 left-0 right-0 flex justify-center gap-6">
          <button 
            onClick={prevSlide}
            className="w-16 h-16 rounded-full bg-slate-900 border border-white/5 flex items-center justify-center text-white hover:bg-slate-800 transition-all hover:scale-110 active:scale-95 shadow-xl"
          >
            <ChevronLeft className="w-8 h-8" />
          </button>
          <button 
            onClick={nextSlide}
            className="w-16 h-16 rounded-full bg-emerald-600 flex items-center justify-center text-white hover:bg-emerald-500 transition-all hover:scale-110 active:scale-95 shadow-xl shadow-emerald-500/20"
          >
            <ChevronRight className="w-8 h-8" />
          </button>
        </div>
      </div>

      {/* Hidden container for PDF export */}
      <div 
        id="pdf-export-root"
        ref={pdfContainerRef}
        style={{ 
          position: 'fixed',
          top: 0,
          left: 0,
          zIndex: -50,
          opacity: 0,
          pointerEvents: 'none',
          width: '1024px', 
          backgroundColor: '#020617' 
        }}
      >
        {SLIDES.map((s, idx) => {
          const SlideIcon = s.icon;
          const bgColors = {
            emerald: '#059669',
            rose: '#e11d48',
            blue: '#2563eb',
            amber: '#d97706',
            purple: '#9333ea'
          };
          const textColors = {
            emerald: '#10b981',
            rose: '#f43f5e',
            blue: '#3b82f6',
            amber: '#f59e0b',
            purple: '#a855f7'
          };
          
          if (idx === 0) {
            return (
              <div 
                key={idx} 
                className="pdf-slide"
                style={{ 
                  width: '1024px',
                  height: '576px',
                  backgroundColor: '#020617',
                  display: 'flex',
                  flexDirection: 'column',
                  alignItems: 'center',
                  justifyContent: 'center',
                  textAlign: 'center',
                  overflow: 'hidden',
                  position: 'relative'
                }}
              >
                <div style={{ position: 'absolute', top: '-10%', left: '-10%', width: '40%', height: '40%', background: 'radial-gradient(circle, rgba(16, 185, 129, 0.1) 0%, transparent 70%)', borderRadius: '50%' }} />
                <div style={{ position: 'absolute', bottom: '-10%', right: '-10%', width: '40%', height: '40%', background: 'radial-gradient(circle, rgba(16, 185, 129, 0.1) 0%, transparent 70%)', borderRadius: '50%' }} />
                
                <div style={{ 
                  width: '8rem', height: '8rem', borderRadius: '2rem', 
                  backgroundColor: '#059669', color: 'white',
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                  marginBottom: '2.5rem', boxShadow: '0 20px 40px rgba(5, 150, 105, 0.3)'
                }}>
                  <SlideIcon size={64} />
                </div>
                <h1 style={{ fontSize: '4.5rem', fontWeight: 900, color: '#ffffff', letterSpacing: '-0.02em', margin: 0, lineHeight: 1 }}>{s.title}</h1>
                <h2 style={{ fontSize: '1.25rem', fontWeight: 500, color: '#94a3b8', marginTop: '1rem', marginBottom: '2.5rem' }}>{s.subtitle}</h2>
                <div style={{ padding: '0.5rem 1.5rem', borderRadius: '9999px', backgroundColor: 'rgba(16, 185, 129, 0.1)', color: '#10b981', fontSize: '10px', fontWeight: 900, textTransform: 'uppercase', letterSpacing: '0.25em', border: '1px solid rgba(16, 185, 129, 0.2)' }}>
                  {s.tag}
                </div>
              </div>
            );
          }

          return (
            <div 
              key={idx} 
              className="pdf-slide"
              style={{ 
                width: '1024px',
                height: '576px',
                backgroundColor: '#020617',
                display: 'flex',
                overflow: 'hidden',
                borderBottom: '1px solid rgba(255, 255, 255, 0.1)'
              }}
            >
              <div 
                style={{ 
                  width: '40%', 
                  padding: '3rem', 
                  display: 'flex', 
                  flexDirection: 'column', 
                  alignItems: 'center', 
                  justifyContent: 'center', 
                  textAlign: 'center',
                  backgroundColor: 'rgba(15, 23, 42, 0.5)'
                }}
              >
                <div 
                  style={{ 
                    width: '6rem', 
                    height: '6rem', 
                    borderRadius: '1.5rem', 
                    display: 'flex', 
                    alignItems: 'center', 
                    justifyContent: 'center', 
                    marginBottom: '1.5rem',
                    backgroundColor: bgColors[s.color as keyof typeof bgColors],
                    color: '#ffffff'
                  }}
                >
                  <SlideIcon size={48} />
                </div>
                <div 
                  style={{ 
                    padding: '0.25rem 0.75rem', 
                    borderRadius: '9999px', 
                    fontSize: '10px', 
                    fontWeight: 900, 
                    letterSpacing: '0.1em', 
                    textTransform: 'uppercase', 
                    marginBottom: '1rem',
                    backgroundColor: 'rgba(15, 23, 42, 0.8)',
                    color: textColors[s.color as keyof typeof textColors],
                    border: `1px solid ${textColors[s.color as keyof typeof textColors]}33`
                  }}
                >
                  {s.tag}
                </div>
              </div>
              <div 
                style={{ 
                  width: '60%', 
                  padding: '4rem', 
                  display: 'flex', 
                  flexDirection: 'column', 
                  justifyContent: 'center',
                  backgroundColor: '#0f172a' 
                }}
              >
                <h2 style={{ fontSize: '2.25rem', fontWeight: 900, color: '#ffffff', marginTop: 0, marginBottom: '0.5rem' }}>{s.title}</h2>
                <h3 style={{ fontSize: '1.125rem', fontWeight: 500, color: '#94a3b8', marginBottom: '1.5rem', marginTop: 0 }}>{s.subtitle}</h3>
                <p style={{ fontSize: '1rem', lineHeight: 1.625, color: '#cbd5e1', fontStyle: 'italic', margin: 0 }}>
                  "{s.content}"
                </p>
                <div style={{ marginTop: '2rem', display: 'flex', gap: '1rem', opacity: 0.5 }}>
                   <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                     <Lock size={12} color="#10b981" />
                     <span style={{ fontSize: '8px', fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.1em', color: '#64748b', margin: 0 }}>Protocol-Verified</span>
                   </div>
                   <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                     <Target size={12} color="#10b981" />
                     <span style={{ fontSize: '8px', fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.1em', color: '#64748b', margin: 0 }}>AAOIFI Compliant</span>
                   </div>
                </div>
              </div>
            </div>
          )
        })}
      </div>
    </div>
  );
}

