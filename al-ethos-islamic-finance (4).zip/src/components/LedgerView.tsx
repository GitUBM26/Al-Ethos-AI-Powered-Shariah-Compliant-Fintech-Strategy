import React from 'react';
import { Block } from '../types';
import { ShieldCheck, ShieldAlert, Cpu, Lock } from 'lucide-react';
import { cn, formatDate } from '../lib/utils';

interface LedgerViewProps {
  chain: Block[];
}

export function LedgerView({ chain }: LedgerViewProps) {
  return (
    <div className="space-y-6 max-w-7xl mx-auto">
      <header>
        <h2 className="text-3xl font-sans font-bold text-white tracking-tight">Immutable Block Ledger</h2>
        <p className="text-slate-500 text-sm mt-1">Shariah-integrated blockchain record of all contract stages and transactions.</p>
      </header>

      <div className="bento-card !p-0 overflow-hidden shadow-2xl">
        <div className="grid grid-cols-12 bg-slate-900/80 border-b border-bento-border/30 p-5">
          <div className="col-span-1 text-[10px] font-bold text-slate-500 uppercase tracking-widest">Index</div>
          <div className="col-span-2 text-[10px] font-bold text-slate-500 uppercase tracking-widest">Timestamp</div>
          <div className="col-span-4 text-[10px] font-bold text-slate-500 uppercase tracking-widest">Transaction Hash</div>
          <div className="col-span-3 text-[10px] font-bold text-slate-500 uppercase tracking-widest">Veea Compliance</div>
          <div className="col-span-2 text-[10px] font-bold text-slate-500 uppercase tracking-widest text-right">Verification</div>
        </div>

        <div className="divide-y divide-bento-border/20 max-h-[600px] overflow-y-auto custom-scrollbar">
          {chain.slice().reverse().map((block) => (
            <div key={block.hash} className="grid grid-cols-12 p-5 hover:bg-white/[0.02] transition-colors group cursor-pointer">
              <div className="col-span-1 py-1 font-mono text-emerald-500 text-sm font-bold">
                #{block.index.toString().padStart(3, '0')}
              </div>
              <div className="col-span-2 py-1 text-slate-400 text-xs font-medium">
                {formatDate(block.timestamp)}
              </div>
              <div className="col-span-4 py-1 flex items-center gap-3">
                <div className="w-8 h-8 rounded-lg bg-slate-900 flex items-center justify-center border border-slate-800">
                  <Lock className="w-4 h-4 text-slate-600 group-hover:text-gold-bright transition-colors" />
                </div>
                <span className="font-mono text-[10px] text-slate-400 break-all truncate max-w-[220px] group-hover:text-slate-200 transition-colors">
                  {block.hash}
                </span>
              </div>
              <div className="col-span-3 py-1 space-y-1.5">
                 <div className="flex items-center gap-2">
                    {block.monitoringStatus === 'PASSED' ? (
                      <ShieldCheck className="w-4 h-4 text-emerald-500" />
                    ) : (
                      <ShieldAlert className="w-4 h-4 text-amber-500" />
                    )}
                    <span className={cn(
                      "text-[10px] font-bold uppercase tracking-widest",
                      block.monitoringStatus === 'PASSED' ? "text-emerald-500" : "text-amber-500"
                    )}>
                      {block.monitoringStatus}
                    </span>
                 </div>
                 <p className="text-[10px] text-slate-500 italic max-w-[280px] line-clamp-1 group-hover:line-clamp-none transition-all leading-relaxed">
                   "{block.shariahAdvice}"
                 </p>
              </div>
              <div className="col-span-2 py-1 flex justify-end items-center">
                <span className="px-3 py-1 bg-emerald-500/10 border border-emerald-500/20 rounded-full text-[10px] font-bold text-emerald-400">
                  VALIDATED
                </span>
              </div>
            </div>
          ))}
        </div>

        {chain.length === 0 && (
          <div className="p-20 text-center text-slate-600">
            <Cpu className="w-12 h-12 mx-auto mb-4 opacity-20 animate-pulse" />
            <p className="text-sm font-medium">Initializing ledger nodes and mounting Shariah Guard...</p>
          </div>
        )}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bento-card bg-emerald-950/20 border-emerald-900/30 flex justify-between items-center">
           <div>
             <h4 className="text-emerald-400 font-bold text-xs mb-1 uppercase tracking-widest">Protocol Integrity</h4>
             <p className="text-emerald-300/70 text-[11px]">Veea-Lobstertrap Shariah Protocol v2.4.1 (Immutable)</p>
           </div>
           <div className="flex items-center gap-3">
              <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
              <span className="text-[10px] font-bold text-emerald-500">OPTIMAL</span>
           </div>
        </div>
        <div className="bento-card flex flex-col justify-center">
           <div className="flex justify-between items-end mb-2">
             <h4 className="text-slate-400 font-bold text-xs uppercase tracking-widest">Distributed Consistency</h4>
             <span className="text-[10px] font-mono text-slate-500">99.999% SYNC</span>
           </div>
           <div className="w-full bg-slate-900 h-1.5 rounded-full overflow-hidden border border-slate-800">
             <div className="bg-emerald-500 h-full w-[99.9%]" />
           </div>
        </div>
      </div>
    </div>
  );
}
