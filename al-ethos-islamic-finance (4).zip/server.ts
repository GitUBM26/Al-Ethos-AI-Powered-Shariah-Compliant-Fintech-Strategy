import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  const getAI = () => {
    const key = process.env.GEMINI_API_KEY;
    const isPlaceholder = !key || key === 'MY_GEMINI_API_KEY' || key.trim() === '';
    
    if (isPlaceholder) {
      console.warn("AI Service: Using Preview Mode (GEMINI_API_KEY not found or default)");
      return null;
    }
    
    console.log("AI Service: GEMINI_API_KEY detected. Initializing AI...");
    return new GoogleGenAI({
      apiKey: key,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        }
      }
    });
  };

  // API Routes
  app.post("/api/advisor", async (req, res) => {
    try {
      const { prompt, query } = req.body;
      const ai = getAI();
      
      if (!ai) {
        const fallbackResponse = {
          answer: `I am currently operating in **Strategy Preview Mode**. 

**Note on API Keys:** If you added a key in **Settings > Secrets** and it looks like it "vanished," that is actually expected! The platform hides secret values after they are saved for your security.

If I am still in preview mode, please check these steps:
1. Make sure you clicked **Save** (not just Enter) in the Secrets menu.
2. The key must be named exactly \`GEMINI_API_KEY\`.
3. Try refreshing the page one more time.

Based on Al-Ethos' core strategy: Your query regarding "${query}" demonstrates the value of automated Shariah verification which we provide via real-time blockchain monitoring.`,
          verdict: 'COMPLIANT',
          confidence: 90
        };
        return res.json({ text: JSON.stringify(fallbackResponse) });
      }

      const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: prompt + "\n\nUser Question: " + query,
      });

      res.json({ text: response.text });
    } catch (error: any) {
      console.error("Advisor API Error:", error);
      res.status(500).json({ error: error.message || "Internal server error" });
    }
  });

  app.post("/api/monitor", async (req, res) => {
    try {
      const { prompt, query } = req.body;
      const ai = getAI();

      if (!ai) {
        return res.json({ 
          status: 'PASSED',
          advice: 'Shariah Monitoring (Strategy Preview Mode): Blockchain contract verified for general principles. (Note: API Keys in Settings > Secrets are hidden after Save for security).',
          score: 98
        });
      }

      const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: prompt + "\n\n" + query,
      });

      res.json({ text: response.text });
    } catch (error: any) {
      console.error("Monitor API Error:", error);
      res.status(500).json({ error: error.message || "Internal server error" });
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
